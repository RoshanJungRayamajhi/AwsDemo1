#!/bin/bash


echo "chature:Adarideya sabapati ji:"


echo "chatur:thuchuck thuchuk"


echo "raju :rancho ek folder bana ke dikha "

mkdir -p rancho 


echo "rancho :ye leh ,bana diya ,ro mat ab"

echo "farcha :riurus ne beizatti kar di ,bola raha he"


echo " farhan:aabaa nhi manege " > farhenitrate.txt
